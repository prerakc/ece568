# Do not alter this file

hostname        = 'id.ca1.bioconnectid.com'
username        = 'ece568'
password        = 'CxNUF-9csTw35U45IJMmPg1T0QgzhMX7cz4JO3WC'

