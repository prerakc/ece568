#!/bin/bash

pip3 install --user requests qrcode-terminal

